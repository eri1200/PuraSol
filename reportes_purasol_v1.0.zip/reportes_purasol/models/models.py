# -*- coding: utf-8 -*-

from odoo import models, fields, api

class reportes_purasol(models.Model):
    _name = 'reportes_purasol.reportes_purasol'

    name = fields.Char()
    value = fields.Integer()
    value2 = fields.Float(compute="_value_pc", store=True)
    description = fields.Text()

    @api.depends('value')
    def _value_pc(self):
        self.value2 = float(self.value) / 100

class Prueba(models.Model):
    _name ='reportes_purasol.prueba'
    _description ='Proyecto de reportes Purasol'

    campo01=fields.Char(string="Title",required=True)
    campo02=fields.Many2one(comodel_name='reportes_purasol.prueba02')

class Prueba02(models.Model):
    _name ='reportes_purasol.prueba02'
    _rec_name='campo03'
    _description ='Proyecto de reportes Purasol'

    campo03=fields.Char(string="Title",required=True)

class Provincia(models.Model):
    _name ='reportes_purasol.provincia'
    _description ='Provincias'
    _rec_name='IdProvincia'
    
    NombreProvincia=fields.Char(string="Title",required=True)
    IdProvincia=fields.Integer(string="Title",required=True)
    
class Canton(models.Model):
    _name ='reportes_purasol.canton'
    _rec_name='IdCanton'
    _description ='Cantones'

    IdCanton=fields.Integer(string="Title",required=True)
    NombreCanton=fields.Char(string="Title",required=True)
    IdProvincia=fields.Many2one(comodel_name='reportes_purasol.provincia')

class Distrito(models.Model):
    _name ='reportes_purasol.distrito'
    _rec_name='NombreDistrito'
    _description ='Distritos'

    NombreDistrito=fields.Char(string="Title",required=True)
    IdCanton=fields.Many2one(comodel_name='reportes_purasol.canton')
    IdDistrito=fields.Integer(string="Title",required=True)

