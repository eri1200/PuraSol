# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Cliente(models.Model):
    _name ='reportes_purasol.cliente'
    _description ='Tabla de clientes del sistema'
    _rec_name='Cedula'

    Cedula=fields.Integer(string="Title",required=True)
    Nombre=fields.Char(string="Title",required=True)
    Apellido=fields.Char(string="Title",required=True)
    Telefono= fields.Integer(string="Title",required=True)
    NombreDistrito=fields.Many2one(comodel_name='reportes_purasol.distrito',required=True)


    
