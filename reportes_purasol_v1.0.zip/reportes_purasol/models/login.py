from odoo import models, fields, api

class Usuario(models.Model):
    _name ='reportes_purasol.usuario'
    _description ='Tabla de usuarios del sistema'

    #IdUsuario=fields.Integer(required=True)
    NombreUsuario=fields.Char(string="Nombre de Usuario",required=True)
    Contrasenna=fields.Char(string="Contraseña",required=True)
    Rol=fields.Char(required=True)

    

    #self._cr.execute("select * from procedure_name(%s);"%(value))