# -*- coding: utf-8 -*-
from odoo import http

# class ReportesPurasol(http.Controller):
#     @http.route('/reportes_purasol/reportes_purasol/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/reportes_purasol/reportes_purasol/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('reportes_purasol.listing', {
#             'root': '/reportes_purasol/reportes_purasol',
#             'objects': http.request.env['reportes_purasol.reportes_purasol'].search([]),
#         })

#     @http.route('/reportes_purasol/reportes_purasol/objects/<model("reportes_purasol.reportes_purasol"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('reportes_purasol.object', {
#             'object': obj
#         })